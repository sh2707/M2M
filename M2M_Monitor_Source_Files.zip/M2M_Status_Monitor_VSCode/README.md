# M2M Status Monitor (C# / Visual Studio Code)

A separate Windows desktop monitor for the M2M Sender and M2M Receiver packages. It does **not** modify either application or its configuration.

## Requirements
- Windows 10/11
- .NET 8 SDK
- Visual Studio Code (C# Dev Kit extension recommended)

## Open and run
1. Extract this ZIP.
2. Open the extracted `M2M_Status_Monitor_VSCode` folder in Visual Studio Code.
3. Open **Terminal → New Terminal**.
4. Run:
   ```powershell
   dotnet run
   ```
5. To create a standalone Windows executable folder, run:
   ```powershell
   dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
   ```
   Published output will be under `bin\Release\net8.0-windows\win-x64\publish\`.

## Checks included
- Whether `M2M_Sender.exe` and `M2M_Receiver_1.exe` processes are running
- Whether the Receiver config's TCP address/port is reachable
- Whether configured Receiver folders exist
- Latest `.udb` file timestamp, when the Receiver `DB` folder can be found
- Local event log: `M2M_Status_Monitor.log`

## Important notes
- The monitor uses the Receiver configuration values it can find beside the project/relative Receiver folder. If the Receiver package is stored elsewhere, put the monitor project beside the extracted `M2M_Sender` and `M2M_Receiver_1` folders, or adjust paths in `MonitorForm.cs`.
- A reachable TCP port does not prove that M2M data exchange is successful; it only checks that a TCP connection can be opened.
- The project was prepared from the supplied EXE/config package structure. It has not been executed on your Windows PC, so please test it in VS Code and share any build error screenshot if one appears.
