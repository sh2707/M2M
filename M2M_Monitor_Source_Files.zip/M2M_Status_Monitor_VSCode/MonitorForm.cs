using System.Diagnostics;
using System.Net.Sockets;
using System.Text;

namespace M2MStatusMonitor;

public sealed class MonitorForm : Form
{
    private readonly Label senderValue = MakeValueLabel();
    private readonly Label receiverValue = MakeValueLabel();
    private readonly Label portValue = MakeValueLabel();
    private readonly Label foldersValue = MakeValueLabel();
    private readonly Label dbValue = MakeValueLabel();
    private readonly Label lastChecked = new() { AutoSize = true, ForeColor = Color.Gainsboro };
    private readonly DataGridView eventsGrid = new();
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 3000 };
    private readonly string logPath = Path.Combine(AppContext.BaseDirectory, "M2M_Status_Monitor.log");
    private readonly string senderExe;
    private readonly string receiverExe;
    private readonly string receiverConfig;
    private string host = "127.0.0.1";
    private int port = 1900;
    private string workingDirectory = @"C:\SH\M2M_ReceivedFolder";
    private string monitorDirectory = @"C:\SH\M2M_SH_Test_ReceivedFolder_Monitor";
    private readonly Dictionary<string, string> lastState = new();

    public MonitorForm()
    {
        Text = "M2M Sender / Receiver Status Monitor";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(850, 590);
        Size = new Size(1050, 720);
        BackColor = Color.FromArgb(23, 21, 31);
        ForeColor = Color.WhiteSmoke;
        Font = new Font("Segoe UI", 9F);

        string baseDir = AppContext.BaseDirectory;
        senderExe = FindFile(baseDir, "M2M_Sender.exe") ?? Path.Combine(baseDir, "..", "M2M_Sender", "M2M_Sender.exe");
        receiverExe = FindFile(baseDir, "M2M_Receiver_1.exe") ?? Path.Combine(baseDir, "..", "M2M_Receiver_1", "M2M_Receiver_1.exe");
        receiverConfig = FindFile(baseDir, "M2M_Receiver_1.cfg") ?? Path.Combine(baseDir, "..", "M2M_Receiver_1", "M2M_Receiver_1.cfg");
        ReadConfig(receiverConfig);
        BuildUi();
        AddEvent("INFO", "Monitor started. Read-only checks only; Sender/Receiver files are not modified.");
        timer.Tick += (_, _) => RefreshStatuses();
        Shown += (_, _) => { RefreshStatuses(); timer.Start(); };
        FormClosed += (_, _) => timer.Stop();
    }

    private void BuildUi()
    {
        var outer = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 4, BackColor = BackColor };
        outer.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
        outer.RowStyles.Add(new RowStyle(SizeType.Absolute, 150));
        outer.RowStyles.Add(new RowStyle(SizeType.Absolute, 88));
        outer.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(outer);

        var header = new Panel { Dock = DockStyle.Fill };
        var title = new Label { Text = "M2M STATUS MONITOR", Dock = DockStyle.Left, AutoSize = false, Width = 430, ForeColor = Color.FromArgb(196, 167, 255), Font = new Font("Segoe UI", 19, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft };
        var refresh = new Button { Text = "Refresh now", Dock = DockStyle.Right, Width = 120, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(62, 48, 86), ForeColor = Color.White, Cursor = Cursors.Hand };
        refresh.Click += (_, _) => RefreshStatuses();
        header.Controls.Add(refresh); header.Controls.Add(title); outer.Controls.Add(header, 0, 0);

        var cards = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5, RowCount = 1, Padding = new Padding(0, 8, 0, 8) };
        for (int i = 0; i < 5; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        AddCard(cards, 0, "M2M Sender", senderValue);
        AddCard(cards, 1, "M2M Receiver", receiverValue);
        AddCard(cards, 2, "TCP Port", portValue);
        AddCard(cards, 3, "Receiver Folders", foldersValue);
        AddCard(cards, 4, "Latest DB file", dbValue);
        outer.Controls.Add(cards, 0, 1);

        var info = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Padding = new Padding(2, 5, 2, 5) };
        info.RowStyles.Add(new RowStyle(SizeType.Percent, 34)); info.RowStyles.Add(new RowStyle(SizeType.Percent, 33)); info.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
        info.Controls.Add(MakeInfoLabel("Receiver working folder: " + workingDirectory), 0, 0);
        info.Controls.Add(MakeInfoLabel("Receiver monitor folder: " + monitorDirectory), 0, 1);
        info.Controls.Add(lastChecked, 0, 2);
        outer.Controls.Add(info, 0, 2);

        var activity = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        activity.RowStyles.Add(new RowStyle(SizeType.Absolute, 34)); activity.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        activity.Controls.Add(new Label { Text = "RECENT ACTIVITY", Dock = DockStyle.Fill, ForeColor = Color.FromArgb(196, 167, 255), Font = new Font("Segoe UI", 12, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        eventsGrid.Dock = DockStyle.Fill; eventsGrid.ReadOnly = true; eventsGrid.AllowUserToAddRows = false; eventsGrid.AllowUserToDeleteRows = false; eventsGrid.RowHeadersVisible = false; eventsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; eventsGrid.BackgroundColor = Color.FromArgb(31, 29, 42); eventsGrid.BorderStyle = BorderStyle.None; eventsGrid.EnableHeadersVisualStyles = false; eventsGrid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(62, 48, 86); eventsGrid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White; eventsGrid.DefaultCellStyle.BackColor = Color.FromArgb(31, 29, 42); eventsGrid.DefaultCellStyle.ForeColor = Color.Gainsboro; eventsGrid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(76, 60, 100); eventsGrid.DefaultCellStyle.SelectionForeColor = Color.White;
        eventsGrid.Columns.Add("time", "Time"); eventsGrid.Columns.Add("status", "Status"); eventsGrid.Columns.Add("message", "Event / Details"); eventsGrid.Columns[0].FillWeight = 26; eventsGrid.Columns[1].FillWeight = 16; eventsGrid.Columns[2].FillWeight = 58;
        activity.Controls.Add(eventsGrid, 0, 1); outer.Controls.Add(activity, 0, 3);
    }

    private static Label MakeValueLabel() => new() { AutoSize = false, Dock = DockStyle.Fill, Text = "Checking…", TextAlign = ContentAlignment.MiddleLeft, ForeColor = Color.WhiteSmoke, Font = new Font("Segoe UI", 12, FontStyle.Bold) };
    private static Label MakeInfoLabel(string text) => new() { Text = text, Dock = DockStyle.Fill, AutoEllipsis = true, ForeColor = Color.Silver, TextAlign = ContentAlignment.MiddleLeft };

    private static void AddCard(TableLayoutPanel parent, int col, string heading, Label value)
    {
        var card = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 8, 0), BackColor = Color.FromArgb(36, 33, 49), Padding = new Padding(11) };
        var label = new Label { Text = heading, Dock = DockStyle.Top, Height = 28, ForeColor = Color.FromArgb(196, 167, 255), Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        card.Controls.Add(value); card.Controls.Add(label); parent.Controls.Add(card, col, 0);
    }

    private static string? FindFile(string root, string fileName)
    {
        try { return Directory.GetFiles(root, fileName, SearchOption.AllDirectories).FirstOrDefault(); }
        catch { return null; }
    }

    private void ReadConfig(string path)
    {
        if (!File.Exists(path)) return;
        try
        {
            foreach (var raw in File.ReadAllLines(path))
            {
                var parts = raw.Split('=', 2);
                if (parts.Length != 2) continue;
                string key = parts[0].Trim(), value = parts[1].Trim();
                if (key == "M2M_Receiver_IP_Address") host = value;
                if (key == "M2M_Receiver_Port" && int.TryParse(value, out int parsedPort)) port = parsedPort;
                if (key == "M2M_Receiver_WorkingDirectory") workingDirectory = value.Replace("\\\\", "\\");
                if (key == "M2M_Receiver_WorkingDirectoryMonitor") monitorDirectory = value.Replace("\\\\", "\\");
            }
        }
        catch (IOException) { }
    }

    private void RefreshStatuses()
    {
        bool sender = IsProcessRunning("M2M_Sender");
        bool receiver = IsProcessRunning("M2M_Receiver_1");
        bool tcp = CanConnect(host, port);
        bool folders = Directory.Exists(workingDirectory) && Directory.Exists(monitorDirectory);
        string db = LatestDbSummary();
        SetStatus(senderValue, sender ? "RUNNING" : "NOT RUNNING", sender);
        SetStatus(receiverValue, receiver ? "RUNNING" : "NOT RUNNING", receiver);
        SetStatus(portValue, tcp ? "REACHABLE" : "UNREACHABLE", tcp);
        SetStatus(foldersValue, folders ? "FOLDERS OK" : "CHECK PATHS", folders);
        SetStatus(dbValue, db, db != "No DB folder" && db != "No .udb files");
        Track("Sender", sender, sender ? "M2M_Sender.exe process detected" : "M2M_Sender.exe process not detected");
        Track("Receiver", receiver, receiver ? "M2M_Receiver_1.exe process detected" : "M2M_Receiver_1.exe process not detected");
        Track("TCP", tcp, tcp ? $"{host}:{port} accepts TCP connections" : $"{host}:{port} is not reachable");
        Track("Folders", folders, folders ? "Both receiver folders exist" : "One or both receiver folders are missing");
        lastChecked.Text = $"Last checked: {DateTime.Now:yyyy-MM-dd HH:mm:ss}    |    DB: {db}";
    }

    private static bool IsProcessRunning(string processName)
    {
        try { return Process.GetProcessesByName(processName).Length > 0; }
        catch { return false; }
    }

    private static bool CanConnect(string address, int targetPort)
    {
        try { using var client = new TcpClient(); var task = client.ConnectAsync(address, targetPort); return task.Wait(900) && client.Connected; }
        catch { return false; }
    }

    private string LatestDbSummary()
    {
        string baseDir = AppContext.BaseDirectory;
        string[] candidates = { Path.Combine(baseDir, "M2M_Receiver_1", "DB"), Path.Combine(baseDir, "..", "M2M_Receiver_1", "DB"), Path.Combine(Path.GetDirectoryName(receiverConfig) ?? "", "DB") };
        foreach (string dir in candidates.Select(Path.GetFullPath).Distinct())
        {
            if (!Directory.Exists(dir)) continue;
            var files = Directory.GetFiles(dir, "*.udb");
            if (files.Length == 0) return "No .udb files";
            var latest = files.Select(f => new FileInfo(f)).OrderByDescending(f => f.LastWriteTime).First();
            return $"{latest.Name} ({latest.LastWriteTime:MM-dd HH:mm})";
        }
        return "No DB folder";
    }

    private void SetStatus(Label label, string text, bool ok)
    {
        label.Text = text;
        label.ForeColor = ok ? Color.LightGreen : Color.Salmon;
    }

    private void Track(string key, bool ok, string message)
    {
        string status = ok ? "OK" : "WARN";
        string signature = status + "|" + message;
        if (lastState.TryGetValue(key, out string? old) && old == signature) return;
        lastState[key] = signature;
        AddEvent(status, message);
    }

    private void AddEvent(string status, string message)
    {
        string stamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        eventsGrid.Rows.Insert(0, stamp, status, message);
        while (eventsGrid.Rows.Count > 200) eventsGrid.Rows.RemoveAt(eventsGrid.Rows.Count - 1);
        try { File.AppendAllText(logPath, $"[{stamp}] [{status}] {message}{Environment.NewLine}", Encoding.UTF8); } catch { }
    }
}
