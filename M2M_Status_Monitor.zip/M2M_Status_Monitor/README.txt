M2M STATUS MONITOR
==================

Purpose
-------
A separate, read-only monitoring tool for the supplied M2M Sender and M2M Receiver EXE packages.
It does not modify, replace, or delete the existing Sender/Receiver files.

Checks included
---------------
1. Whether M2M_Sender.exe is running.
2. Whether M2M_Receiver_1.exe is running.
3. Whether TCP port 127.0.0.1:1900 accepts a connection.
4. Whether the Receiver working and monitor folders from the supplied CFG exist.
5. The most recently modified .udb file in the Receiver DB folder.
6. Timestamped status/event log saved as M2M_Status_Monitor.log.

How to use
----------
1. Extract this ZIP into the SAME parent folder that contains the M2M_Sender and M2M_Receiver_1 folders.
   Example:
      YourFolder\M2M_Sender\
      YourFolder\M2M_Receiver_1\
      YourFolder\M2M_Status_Monitor\
2. On Windows, make sure Python 3 is installed and available as the `python` command.
3. Double-click Run_Monitor.bat.
4. Click Refresh now to run checks immediately. The tool also refreshes every 3 seconds.
5. Click Open log folder to see the log file.

Important notes
---------------
- This is a monitoring tool, not a source-code modification to the original EXE files.
- TCP port status only confirms whether a TCP connection can be opened; it does not prove that application-level data exchange is successful.
- Folder checks use the paths found in the provided Receiver CFG: C:\SH\M2M_ReceivedFolder and C:\SH\M2M_SH_Test_ReceivedFolder_Monitor.
- If your actual machine uses different folders or port, update the constants near the top of M2M_Status_Monitor.py.
- The tool is read-only for the Sender/Receiver programs and database; its own log file is written beside the monitor.
