import os
import sys
import socket
import subprocess
import queue
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

APP_TITLE = 'M2M Sender / Receiver Status Monitor'
REFRESH_MS = 3000
HOST = '127.0.0.1'
PORT = 1900
RECEIVER_WORKING_DIR = r'C:\SH\M2M_ReceivedFolder'
RECEIVER_MONITOR_DIR = r'C:\SH\M2M_SH_Test_ReceivedFolder_Monitor'

class MonitorApp:
    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        root.geometry('960x660')
        root.minsize(780, 560)
        root.configure(bg='#17151f')
        self.events = queue.Queue()
        self.last_states = {}
        self.log_path = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), 'M2M_Status_Monitor.log')

        style = ttk.Style()
        try: style.theme_use('clam')
        except tk.TclError: pass
        style.configure('TFrame', background='#17151f')
        style.configure('TLabel', background='#17151f', foreground='#f1eff8', font=('Segoe UI', 10))
        style.configure('Title.TLabel', font=('Segoe UI', 18, 'bold'), foreground='#c4a7ff')
        style.configure('Sub.TLabel', foreground='#b8b2c9')
        style.configure('TButton', font=('Segoe UI', 10, 'bold'), padding=7)
        style.configure('Treeview', font=('Consolas', 9), rowheight=24)
        style.configure('Treeview.Heading', font=('Segoe UI', 9, 'bold'))

        main = ttk.Frame(root, padding=16); main.pack(fill='both', expand=True)
        header = ttk.Frame(main); header.pack(fill='x')
        ttk.Label(header, text='M2M STATUS MONITOR', style='Title.TLabel').pack(side='left')
        ttk.Label(header, text='Read-only checks • auto refresh every 3 seconds', style='Sub.TLabel').pack(side='right')

        cards = ttk.Frame(main); cards.pack(fill='x', pady=(16, 12))
        self.card_labels = {}
        for key, title in [('sender','M2M Sender'), ('receiver','M2M Receiver'), ('port','TCP Port 1900'), ('folders','Receiver Folders')]:
            frame = tk.Frame(cards, bg='#242131', highlightbackground='#4a3b66', highlightthickness=1, padx=12, pady=10)
            frame.pack(side='left', fill='both', expand=True, padx=(0, 8))
            tk.Label(frame, text=title, bg='#242131', fg='#c4a7ff', font=('Segoe UI', 10, 'bold')).pack(anchor='w')
            value = tk.Label(frame, text='Checking…', bg='#242131', fg='#f1eff8', font=('Segoe UI', 13, 'bold'))
            value.pack(anchor='w', pady=(7, 2))
            detail = tk.Label(frame, text='', bg='#242131', fg='#b8b2c9', font=('Segoe UI', 8), wraplength=190, justify='left')
            detail.pack(anchor='w')
            self.card_labels[key] = (value, detail)

        ttk.Label(main, text='Receiver paths from supplied configuration', style='Sub.TLabel').pack(anchor='w', pady=(0, 4))
        ttk.Label(main, text='Working: ' + RECEIVER_WORKING_DIR).pack(anchor='w')
        ttk.Label(main, text='Monitor: ' + RECEIVER_MONITOR_DIR).pack(anchor='w', pady=(0, 10))
        ttk.Label(main, text='Recent activity', style='Title.TLabel').pack(anchor='w', pady=(2, 6))
        self.tree = ttk.Treeview(main, columns=('time','status','message'), show='headings', height=12)
        for col, label in [('time','Time'),('status','Status'),('message','Event / Details')]: self.tree.heading(col, text=label)
        self.tree.column('time', width=155, stretch=False); self.tree.column('status', width=90, stretch=False); self.tree.column('message', width=640, stretch=True)
        self.tree.pack(fill='both', expand=True)
        self.tree.tag_configure('OK', foreground='#167d42'); self.tree.tag_configure('WARN', foreground='#a56a00'); self.tree.tag_configure('ERROR', foreground='#c62828'); self.tree.tag_configure('INFO', foreground='#5c56a5')
        bottom = ttk.Frame(main); bottom.pack(fill='x', pady=(10, 0))
        self.updated_label = ttk.Label(bottom, text='Starting checks…', style='Sub.TLabel'); self.updated_label.pack(side='left')
        ttk.Button(bottom, text='Refresh now', command=self.refresh).pack(side='right', padx=(8,0))
        ttk.Button(bottom, text='Open log folder', command=self.open_log_folder).pack(side='right')
        self.add_event('INFO', 'Monitor started. Existing Sender/Receiver applications are not modified.')
        self.refresh(); root.after(400, self.drain_events); root.after(REFRESH_MS, self.periodic_refresh)

    def add_event(self, status, message):
        stamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.events.put((stamp, status, message))
        try:
            with open(self.log_path, 'a', encoding='utf-8') as f: f.write(f'[{stamp}] [{status}] {message}\n')
        except OSError: pass

    def drain_events(self):
        try:
            while True:
                stamp, status, message = self.events.get_nowait()
                self.tree.insert('', 0, values=(stamp, status, message), tags=(status,))
                children = self.tree.get_children()
                for item in children[200:]: self.tree.delete(item)
        except queue.Empty: pass
        self.root.after(400, self.drain_events)

    def set_card(self, key, state, detail, status):
        value, detail_label = self.card_labels[key]
        color = {'OK':'#6ee7a0','WARN':'#ffd166','ERROR':'#ff7777','INFO':'#f1eff8'}.get(status, '#f1eff8')
        value.configure(text=state, fg=color); detail_label.configure(text=detail)

    def check_process(self, exe_name):
        if os.name != 'nt': return False, 'Process check is designed for Windows.'
        try:
            result = subprocess.run(['tasklist','/FI',f'IMAGENAME eq {exe_name}','/FO','CSV','/NH'], capture_output=True, text=True, timeout=4, creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            found = exe_name.lower() in result.stdout.lower() and 'INFO:' not in result.stdout
            return found, 'Process detected' if found else 'Process not detected'
        except Exception as exc: return False, 'Process check failed: ' + str(exc)

    def check_port(self):
        try:
            with socket.create_connection((HOST, PORT), timeout=1.5): return True, f'{HOST}:{PORT} accepts TCP connections'
        except OSError as exc: return False, f'{HOST}:{PORT} not reachable ({exc.__class__.__name__})'

    def check_folders(self):
        missing = [p for p in (RECEIVER_WORKING_DIR, RECEIVER_MONITOR_DIR) if not os.path.isdir(p)]
        return (False, 'Missing: ' + '; '.join(missing)) if missing else (True, 'Both configured folders exist')

    def latest_db(self):
        base = os.path.dirname(os.path.abspath(sys.argv[0]))
        folder = os.path.join(base, 'M2M_Receiver_1', 'DB')
        if not os.path.isdir(folder):
            return 'Not found', 'Extract this monitor beside the M2M_Receiver_1 folder'
        try: files = [os.path.join(folder, n) for n in os.listdir(folder) if n.lower().endswith('.udb')]
        except OSError: files = []
        if not files: return 'No .udb files', 'DB folder exists but has no .udb files'
        latest = max(files, key=os.path.getmtime)
        return os.path.basename(latest), 'Modified ' + datetime.fromtimestamp(os.path.getmtime(latest)).strftime('%Y-%m-%d %H:%M:%S')

    def update_if_changed(self, key, status, message):
        signature = (status, message)
        if self.last_states.get(key) != signature:
            self.last_states[key] = signature
            self.add_event(status, f'{key}: {message}')

    def refresh(self):
        s_ok, s_msg = self.check_process('M2M_Sender.exe')
        r_ok, r_msg = self.check_process('M2M_Receiver_1.exe')
        p_ok, p_msg = self.check_port()
        f_ok, f_msg = self.check_folders()
        db_name, db_detail = self.latest_db()
        self.set_card('sender', 'RUNNING' if s_ok else 'NOT RUNNING', s_msg, 'OK' if s_ok else 'WARN')
        self.set_card('receiver', 'RUNNING' if r_ok else 'NOT RUNNING', r_msg, 'OK' if r_ok else 'WARN')
        self.set_card('port', 'REACHABLE' if p_ok else 'UNREACHABLE', p_msg, 'OK' if p_ok else 'ERROR')
        self.set_card('folders', 'OK' if f_ok else 'CHECK PATHS', f_msg, 'OK' if f_ok else 'WARN')
        self.update_if_changed('Sender', 'OK' if s_ok else 'WARN', s_msg)
        self.update_if_changed('Receiver', 'OK' if r_ok else 'WARN', r_msg)
        self.update_if_changed('TCP port', 'OK' if p_ok else 'ERROR', p_msg)
        self.update_if_changed('Folders', 'OK' if f_ok else 'WARN', f_msg)
        self.update_if_changed('Latest DB', 'INFO', f'{db_name} — {db_detail}')
        self.updated_label.configure(text=f'Last checked: {datetime.now().strftime("%H:%M:%S")} | Latest DB: {db_name}')

    def periodic_refresh(self):
        self.refresh(); self.root.after(REFRESH_MS, self.periodic_refresh)

    def open_log_folder(self):
        folder = os.path.dirname(self.log_path)
        try:
            if os.name == 'nt': os.startfile(folder)
            elif sys.platform == 'darwin': subprocess.Popen(['open', folder])
            else: subprocess.Popen(['xdg-open', folder])
        except Exception as exc: messagebox.showerror('Cannot open folder', str(exc))

def main():
    root = tk.Tk(); MonitorApp(root); root.mainloop()

if __name__ == '__main__': main()
