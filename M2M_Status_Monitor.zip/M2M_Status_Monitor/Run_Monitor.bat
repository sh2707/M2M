@echo off
cd /d "%~dp0"
python M2M_Status_Monitor.py
if errorlevel 1 pause
